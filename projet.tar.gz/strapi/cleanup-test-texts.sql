-- Supprimer la table test_texts et toutes ses dépendances
DROP TABLE IF EXISTS public.test_texts CASCADE;
