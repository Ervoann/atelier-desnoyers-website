const { Client } = require('pg');

const client = new Client({
  connectionString: 'postgresql://postgres:VClT3LaldYII1hVDT%24S1OYRM8VO%40Ehae@db.nhkcjytfmwpgetdmzxut.supabase.co:5432/postgres?sslmode=no-verify',
  ssl: {
    rejectUnauthorized: false
  }
});

async function cleanup() {
  try {
    await client.connect();
    console.log('✅ Connecté à Supabase');

    const result = await client.query('DROP TABLE IF EXISTS public.test_texts CASCADE;');
    console.log('✅ Table test_texts supprimée avec CASCADE');

    await client.end();
    console.log('✅ Terminé !');
  } catch (error) {
    console.error('❌ Erreur:', error.message);
    process.exit(1);
  }
}

cleanup();
